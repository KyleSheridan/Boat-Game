﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigBoatDropper : MonoBehaviour
{
    [Header("Wait Time")]
    public float minTime;       //Minimum time to wait before next drop
    public float maxTime;       //Maximum time to wait before next drop

    [Header("Drop Array")]
    public GameObject[] drops;  //Array of droppable items

    private bool spawnable = true;  //To stop items being dropped every frame
    private int maxRand = 0;        //total random for spawn chance

    private void Start()
    {
        foreach (GameObject drop in drops)
        {
            maxRand += drop.GetComponent<Item>().spawnChance;       //max rand = all items spawnchance in array added together
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (spawnable)
        {
            Spawn();    //Spawn random item

            float wait = Random.Range(minTime, maxTime);    //Generate random wait time

            StartCoroutine(WaitToSpawn(wait));      //Wait for wait time
        }
    }

    public void Spawn()
    {
        int randomDrop = Mathf.FloorToInt(Random.Range(0, maxRand)); //random item

        int currentRand = 0;        //the current spawnchance for random item
        int spawnItem = 0;          //Item in array
        bool canSpawn = true;      //only spawn one item per loop

        foreach (GameObject item in drops)
        {
            currentRand += item.GetComponent<Item>().spawnChance;       //spawnchance of current item + spawnchance of previous items

            if(randomDrop < currentRand && canSpawn)           //if random number is < currnent rand and there hasnt been an item spawned
            {
                Instantiate(drops[spawnItem], transform.position, Quaternion.Euler(Vector3.zero));      //spawn item
                canSpawn = false;                                                                      //spawnable = false
            }

            spawnItem++;        //number in array
        }
    }

    //wait between spawns
    private IEnumerator WaitToSpawn(float waitTime) 
    {
        spawnable = false;

        yield return new WaitForSeconds(waitTime);

        spawnable = true;
    }
}
