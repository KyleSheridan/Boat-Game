﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PlayerStats : MonoBehaviour
{
    public GameMaster gm;

    [Header("Health Bar")]
    public Slider healthBar;        //slider to show health

    [Header("Player Stats")]
    public float maxHealth;     //maximum health to work out percentage
    public float moveSpeed;     //speed player moves at
    public float playerDmg;     //damage player deals
    public int playerNum;       //number of player for controls


    public TextMeshProUGUI livesImg;

    //player stats as structure
    public struct Player {
        private float speed_;
        private float health_;
        private float damage_;
        private int lives_;
        private bool invinsible_;

        //Properties
        public float Speed
        {
            get { return speed_; }
            set { speed_ = value; }
        }
        public float Health
        {
            get { return health_; }
            set { health_ = value; }
        }
        public float Damage
        {
            get { return damage_; }
            set { damage_ = value; }
        }
        public int Lives
        {
            get { return lives_; }
            set { lives_ = value; }
        }
        public bool IsInvincible
        {
            get { return invinsible_; }
            set { invinsible_ = value; }
        }

        //deal damage to player (use - to heal)
        public void TakeDamage(float amount)
        {
            if (!invinsible_ || amount < 0)
            {
                this.Health -= amount;  
            }
        }

        //add lives to player (use - to lose lives)
        public void AddLives(int num)
        {
            this.Health = 100;
            this.Lives += num;
        }

        //Construtor
        public Player(float speed, float health, float damage)
        {
            speed_ = speed;
            health_ = health;
            damage_ = damage;
            invinsible_ = false;
            lives_ = 3;
        }
    }

    public Player stats;        //create instance of players stats
    //public Player stats = new Player(5f, 100f, 10f);

    // Start is called before the first frame update
    void Start()
    {
        gm = GameObject.FindGameObjectWithTag("GM").GetComponent<GameMaster>();     //find game master for game over function
        healthBar = GameObject.FindGameObjectWithTag("P" + playerNum + "Health").GetComponent<Slider>();        //find health bar based on player number
        stats = new Player(moveSpeed, maxHealth, playerDmg);        //assign values to player stats
        livesImg = GameObject.FindGameObjectWithTag("P" + playerNum + "Lives").GetComponent<TextMeshProUGUI>();
    }

    // Update is called once per frame
    void Update()
    {
        //if health is above max health then make it = max health
        if (stats.Health > maxHealth)
        {
            stats.Health = maxHealth;
        } 

        //if health < 0 then player loses life
        if (stats.Health <= 0)
        {
            stats.AddLives(-1);

            //if lives is = 0 then game over, other player wins
            if(stats.Lives <= 0)
            {
                gm.GameOver(playerNum);
            }
        }

        //Turn on particle effect when invinsible
        if (stats.IsInvincible)
        {
            transform.Find("Invinsible").gameObject.SetActive(true);
        }
        else
        {
            transform.Find("Invinsible").gameObject.SetActive(false);
        }
        

        //health as percentage of max health
        float healthPercent = stats.Health / maxHealth;

        healthBar.value = healthPercent;        //health bar percent full

        livesImg.text = stats.Lives.ToString();
    }
}
