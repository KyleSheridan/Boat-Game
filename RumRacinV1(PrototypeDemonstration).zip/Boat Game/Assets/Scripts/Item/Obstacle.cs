﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacle : Item
{
    public float damage = 10f;      //damage dealt to player

    // Update is called once per frame
    void Update()
    {
        Drift();        //move left
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //if collides with player
        if (collision.gameObject.tag == "Player1" || collision.gameObject.tag == "Player2")
        {
            //Variable to access player's stats
            PlayerStats player = collision.gameObject.GetComponent<PlayerStats>();

            player.stats.TakeDamage(damage);    //Damage player

            //ui to show damage dealt
            GameObject ui = Instantiate(canvas, collision.gameObject.transform.position, Quaternion.Euler(Vector3.zero));

            //display ui
            ui.GetComponent<ItemUI>().target = collision.gameObject.transform;

            //amount of damage dealt for ui
            if(!player.stats.IsInvincible || damage <= 0)
            {
                ui.GetComponent<HealUI>().amount = (damage * -1);
            }
            else
            {
                //0 damage if invinsible
                ui.GetComponent<HealUI>().amount = 0;
            }


            //decrease score if hit player
            if (collision.gameObject.tag == "Player1")
            {
                Score.p1Score -= (damage * Timer.multiplier);
            }
            else
            {
                Score.p2Score -= (damage * Timer.multiplier);
            }

            DestroyItem();      //destroys item
        }

        //increase score if avoided
        if (collision.gameObject.tag == "Collector")
        {
            Score.p1Score += (damage * Timer.multiplier);
            Score.p2Score += (damage * Timer.multiplier);
            DestroyItem();
        }
    }
}
