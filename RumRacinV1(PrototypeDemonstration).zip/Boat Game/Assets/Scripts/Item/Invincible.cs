﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Invincible : Item
{
    [Header("Invinsibility")]
    public float powerUpTime;       //Invinsibility Time

    //move slower than other items
    public override void Drift()
    {
        transform.Translate(Vector3.left * (moveSpeed * 0.6f) * Time.deltaTime);
    }

    // Update is called once per frame
    void Update()
    {
        Drift();        //move left
    }

    public IEnumerator TurnInvinsible(PlayerStats player, float waitTime)
    {
        //turn invinsible
        player.stats.IsInvincible = true;

        //disable sprite and collider so other player can't pick it up
        GetComponent<SpriteRenderer>().enabled = false;
        GetComponent<BoxCollider2D>().enabled = false;
        
        yield return new WaitForSeconds(waitTime);      //wait

        player.stats.IsInvincible = false;      //turn off invinsible

        DestroyItem();        //destroy item
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //if collides with a player
        if(collision.gameObject.tag == "Player1" || collision.gameObject.tag == "Player2")
        {
            //turn player invinsible
            StartCoroutine(TurnInvinsible(collision.GetComponent<PlayerStats>(), powerUpTime));

            //ui invinsible text
            GameObject ui = Instantiate(canvas, collision.gameObject.transform.position, Quaternion.Euler(Vector3.zero));

            //display text
            ui.GetComponent<ItemUI>().target = collision.gameObject.transform;

            //increase score of player that collides with this
            if (collision.gameObject.tag == "Player1")
            {
                Score.p1Score += (100 * Timer.multiplier);
            }
            else
            {
                Score.p2Score += (100 * Timer.multiplier);
            }
        }
        //decrease score if missed
        if(collision.gameObject.tag == "Collector")
        {
            Score.p1Score -= 100 * Timer.multiplier;
            Score.p2Score -= 100 * Timer.multiplier;

            DestroyItem();
        }
    }
}
