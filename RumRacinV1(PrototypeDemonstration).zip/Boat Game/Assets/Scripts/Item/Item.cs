﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    [Header("Item Properties")]
    public float moveSpeed = 5f;        //speed item moves
    public int spawnChance;           //chance of item spawning

    [Header("UI Prefab")]
    public GameObject canvas;

    public virtual void Drift()
    {
        transform.Translate(Vector3.left * moveSpeed * Time.deltaTime);     //move item left
    }

    //Destroy item
    protected void DestroyItem()
    {
        Destroy(gameObject);
    }
}

