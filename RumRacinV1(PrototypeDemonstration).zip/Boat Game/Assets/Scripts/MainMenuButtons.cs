﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuButtons : MonoBehaviour
{
    //start the game
    public void StartGame()
    {
        SceneManager.LoadScene("BoatRace");
    }

    //close the application
    public void QuitGame()
    {
        Application.Quit();
    }
}
