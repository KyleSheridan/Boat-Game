﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Parallax : MonoBehaviour
{

    public float spawnPointX;       //Where the next prefab will spawn
    public float startPointX;       //Where the current prefab starts to check for next spawn
    public float destroyPointX;     //Where the current prefab is destroyed
    public float parallaxSpeed;     //The speed the prefab moves at

    //private float startPointX;
    private bool spawnable = true;      //To only spawn one prefab
    private bool destroyable = true;    //To only destroy one prefab

    private Vector3 spawnVector;
    //private Vector3 startVector;


    public GameObject spawnPrefab;      //The prefab to be spawned

    // Start is called before the first frame update
    void Start()
    {
        //spawnVector = new Vector3(spawnPointX, this.transform.position.y);  //spawnPointX to Vector3
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector3.left * parallaxSpeed * Time.deltaTime); //Move left

        if (this.transform.position.x <= startPointX && spawnable)      //Check to spawn
        {
            //Making spawnVector = the position that the next background tile should spawn at then spawning it.
            spawnVector = new Vector3((this.transform.position.x + spawnPointX) - startPointX, this.transform.position.y);
            Instantiate(spawnPrefab, spawnVector, this.transform.rotation);
            spawnable = false;
        }

        if (this.transform.position.x <= destroyPointX && destroyable)  //Check to destroy
        {
            Destroy(gameObject);
            destroyable = false;
        }
    }
}
