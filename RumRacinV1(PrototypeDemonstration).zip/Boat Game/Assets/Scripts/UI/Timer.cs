﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Timer : MonoBehaviour
{
    //seconds and minutes
    private float seconds = 0f;
    private int minutes = 0;

    public static float multiplier = 1f;        //multiplier for score
    private bool canAdd = true;         //to check if multiplier can be increased

    public GameMaster gm;       //for gameover screen

    //timer as text
    public TextMeshProUGUI secs;
    public TextMeshProUGUI mins;

    // Start is called before the first frame update
    void Start()
    {
        gm = GameObject.FindGameObjectWithTag("GM").GetComponent<GameMaster>(); //for game over
    }

    // Update is called once per frame
    void Update()
    {
        //increase timer
        seconds += Time.deltaTime;

        //if 30 seconds have passed increase multiplier
        if (seconds >= 30 && canAdd)
        {
            multiplier += 0.5f;
            canAdd = false;
        }


        if(seconds >= 60)
        {
            seconds -= 60;      //reset seconds after 1 minute
            minutes++;          //increse minute count
            mins.text = minutes.ToString();     //change minute text

            //if 5 minutes pass end game
            if (minutes >= 5)
            {
                if (Score.p1Score > Score.p2Score)
                {
                    gm.GameOver(2);
                }
                else
                {
                    gm.GameOver(1);
                }
            }
            //increase multiplier as 30 seconds have passed
            multiplier += 0.5f; 
            canAdd = true;
        }

        //round seconds to 2dp
        float secsRounded = Mathf.Round(seconds * 100) / 100;

        //if seconds is less than 10 put a 0 before. display seconds.
        if(seconds < 10)
        {
            secs.text = "0" + secsRounded;
        }
        else
        {
            secs.text = secsRounded.ToString();
        }
    }
}
