﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUpUI : ItemUI
{
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(DestroyUI(1));       //destroy after 1 second
    }

    // Update is called once per frame
    void Update()
    {
        FollowPlayer();     //FollowPlayer player
    }
}
