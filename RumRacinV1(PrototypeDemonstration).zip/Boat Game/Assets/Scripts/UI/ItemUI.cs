﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemUI : MonoBehaviour
{
    public Transform target;        //player to follow


    //follow player
    protected void FollowPlayer()
    {
        transform.position = target.position;
    }

    //destroy item after an amount of time
    public IEnumerator DestroyUI(float seconds)
    {
        yield return new WaitForSeconds(seconds);

        Destroy(gameObject);
    }
}
