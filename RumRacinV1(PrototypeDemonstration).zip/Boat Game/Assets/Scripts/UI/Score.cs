﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Score : MonoBehaviour
{
    public static float p1Score = 0f;       //player 1 score
    public static float p2Score = 0f;       //player 2 score

    public TextMeshProUGUI p1Text;          //text for player 1 score
    public TextMeshProUGUI p2Text;          //text for player 2 score

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //if score is less than 0 score = 0
        if (p1Score < 0)
        {
            p1Score = 0;
        }
        if(p2Score < 0)
        {
            p2Score = 0;
        }

        //score as text with 5 digits
        p1Text.text = p1Score.ToString("00000");
        p2Text.text = p2Score.ToString("00000");
    }
}
