﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class HealUI : ItemUI
{
    public float amount;        //number to be displayed
    private TextMeshProUGUI healthText;     //text to change

    // Start is called before the first frame update
    void Start()
    {
        //Find text
        healthText = GetComponentInChildren<TextMeshProUGUI>();

        //Change text
        Amount(amount);

        //destroy after 1 second
        StartCoroutine(DestroyUI(1));
    }

    // Update is called once per frame
    void Update()
    {
        FollowPlayer();     //follow player
    }

    private void Amount(float value)
    {
        //if amount is > 0 text will be grean and show +amount (heal)
        if(value > 0)
        {
            healthText.text = "+" + value;
            healthText.color = new Color(0, 255, 0);
        }
        //if amount is < 0 text will be green and show -amount (damage)
        else if (value < 0)
        {
            healthText.text = value.ToString();
            healthText.color = new Color(255, 0, 0);
        }
        //if amount = 0 text will be white and show -0
        else
        {
            healthText.text = "-0";
            healthText.color = new Color(255, 255, 255);
        }
    }
}
