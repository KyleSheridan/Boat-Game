﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonManager : MonoBehaviour
{
    //Reload current scene
    public void Restart()
    {
        SceneManager.LoadScene("BoatRace");
        BigBoatMovement.canMove = true;     //big boat can move
        Time.timeScale = 1;                 //everything else can move

        //score and score multiplier is reset
        Timer.multiplier = 1;
        Score.p1Score = 0;
        Score.p2Score = 0;
    }

    //close the application
    public void EndGame()
    {
        Application.Quit();
    }
}
