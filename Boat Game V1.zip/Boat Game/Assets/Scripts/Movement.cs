﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    //Declaring variables for user inputs
    private float horizontal;
    private float vertical;
    private float alt;
    private float alt2;

    public int playerNum; //To get correct controls
    public float speed = 5f; //Assigns speed value
    public float drag = 0.6f; //To make boat move back slowly when not moving

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector2 direction = Direction();
        if (direction == Vector2.zero)
        {
            //Boat moves back when not moving
            transform.Translate(Vector2.left * (speed * drag) * Time.deltaTime);
        } else
        {
            transform.Translate(direction * speed * Time.deltaTime);    //Move based on inputs
        }
    }

    private Vector3 Direction()
    {
        //Getting inputs and assinging them horizontal / vertical
        horizontal = Input.GetAxis("P" + playerNum + "Horizontal");
        vertical = Input.GetAxis("P" + playerNum + "Vertical");
        
        //Returning inputs as Vector
        Vector3 d = new Vector3(horizontal, vertical);
        return d;
    }
}
