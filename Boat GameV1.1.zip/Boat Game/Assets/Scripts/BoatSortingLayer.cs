﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoatSortingLayer : MonoBehaviour
{
    public GameObject boat1;
    public GameObject boat2;

    // Start is called before the first frame update
    void Start()
    {
        //Finding the boats
        boat1 = GameObject.FindGameObjectWithTag("Player1");
        boat2 = GameObject.FindGameObjectWithTag("Player2");
    }

    // Update is called once per frame
    void Update()
    {
        //Check to see which boat is higher
        if (boat2.transform.position.y <= boat1.transform.position.y)
        {
            //Setting the sorting order so lower boat is displayed ontop
            boat1.GetComponentInChildren<SpriteRenderer>().sortingOrder = 7;
            boat2.GetComponentInChildren<SpriteRenderer>().sortingOrder = 8;
        } else
        {
            boat2.GetComponentInChildren<SpriteRenderer>().sortingOrder = 7;
            boat1.GetComponentInChildren<SpriteRenderer>().sortingOrder = 8;
        }
    }
}
