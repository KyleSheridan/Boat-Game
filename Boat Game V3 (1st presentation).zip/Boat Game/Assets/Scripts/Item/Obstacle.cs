﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacle : Item
{
    public float damage = 10f;      //damage dealt to player

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Drift();        //move left
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //if collides with player
        if (collision.gameObject.tag == "Player1" || collision.gameObject.tag == "Player2")
        {
            //Debug.Log("Inheritence works! =D");

            //Variable to access player's stats
            PlayerStats player = collision.gameObject.GetComponent<PlayerStats>();

            player.stats.Health -= damage;      //Damage player

            DestroyItem();      //destroys item
        }
    }
}
