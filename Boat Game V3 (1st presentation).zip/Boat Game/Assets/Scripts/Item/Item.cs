﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    public float moveSpeed = 5f;        //speed item moves


    // Start is called before the first frame update
    void Start()
    {
        
    }

    protected void Drift()
    {
        transform.Translate(Vector3.left * moveSpeed * Time.deltaTime);     //move item left
    }

    //Destroy item
    protected void DestroyItem()
    {
        Destroy(gameObject);
    }
}

