﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameMaster : MonoBehaviour
{
    public Canvas gameOver;     //game over screen
    public Text playerWin;      //to show which player won

    // Start is called before the first frame update
    void Start()
    {
        playerWin = GameObject.FindGameObjectWithTag("PlayerNumTxt").GetComponent<Text>();      //find text
        gameOver = GameObject.FindGameObjectWithTag("GameOver").GetComponent<Canvas>();         //find canvas
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void GameOver(int playerNumber)
    {
        //if player dies other player wins
        if (playerNumber == 1)
        {
            playerWin.text = "2";
        } else
        {
            playerWin.text = "1";
        }

        gameOver.enabled = true;    //enable game over screen
    }
}
