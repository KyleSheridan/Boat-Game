﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigBoatMovement : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 0.5f;  //speed
    public float rotAngle = 15f;    //rotation angle

    [Header("Y Values")]
    public float minY;      //min y value
    public float maxY;      //max y value

    private float yValue;   //target on y
    private Vector3 target; //yValue to Vector
    //Lerp to y, if statement for y, when reaches y, create new y. 


    // Start is called before the first frame update
    void Start()
    {
        yValue = transform.position.y;  //current y position for if statement
    }

    // Update is called once per frame
    void Update()
    {
        //to check if the big boat has reached the target
        if (transform.position.y < yValue + 0.1 && transform.position.y > yValue - 0.1)
        {
            Debug.Log("if statement works");

            //random y value
            yValue = Random.Range(minY, maxY);

            Debug.Log(yValue);

            //y value to vector
            target = new Vector3(transform.position.x, yValue);

            
        }

        //slowely move to target
        transform.position = Vector3.Lerp(transform.position, target, moveSpeed);
    }
}
