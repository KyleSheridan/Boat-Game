﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigBoatDropper : MonoBehaviour
{
    [Header("Wait Time")]
    public float minTime;       //Minimum time to wait before next drop
    public float maxTime;       //Maximum time to wait before next drop

    [Header("Drop Array")]
    public GameObject[] drops;  //Array of droppable items

    private bool spawnable = true;  //To stop items being dropped every frame

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (spawnable)
        {
            Spawn();    //Spawn random item

            float wait = Random.Range(minTime, maxTime);    //Generate random wait time

            StartCoroutine(WaitToSpawn(wait));      //Wait for wait time
        }
    }

    public void Spawn()
    {
        int randomDrop = Mathf.FloorToInt(Random.Range(0, drops.Length));   //Generate random item in array

        Instantiate(drops[randomDrop], transform.position, Quaternion.Euler(Vector3.zero));     //Spawn item at big boat position
    }

    private IEnumerator WaitToSpawn(float waitTime)
    {
        spawnable = false;

        yield return new WaitForSeconds(waitTime);

        spawnable = true;
    }
}
